
import React, { useState } from 'react';
import { Event, Booking } from '../types';
import Button from './Button';

interface BookingModalProps {
  event: Event;
  onClose: () => void;
  onComplete: (booking: Booking) => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ event, onClose, onComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    tickets: 1
  });

  const total = formData.tickets * event.price;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      const newBooking: Booking = {
        id: 'B-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        eventId: event.id,
        customerName: formData.name,
        customerEmail: formData.email,
        tickets: formData.tickets,
        totalPrice: total,
        status: 'confirmed',
        timestamp: new Date().toISOString()
      };
      onComplete(newBooking);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Book Tickets</h2>
            <p className="text-sm text-slate-500">{event.title}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="flex justify-between items-center mb-8 px-8">
            <div className="flex flex-col items-center gap-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold transition-colors ${step >= 1 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>1</div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500">Details</span>
            </div>
            <div className="flex-1 h-0.5 bg-slate-100 mx-4"></div>
            <div className="flex flex-col items-center gap-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold transition-colors ${step >= 2 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>2</div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500">Confirm</span>
            </div>
          </div>

          {step === 1 ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                <input 
                  type="text" 
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Jane Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address</label>
                <input 
                  type="email" 
                  required
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  placeholder="jane@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Number of Tickets</label>
                <div className="flex items-center gap-4">
                  <input 
                    type="range" 
                    min="1" 
                    max={Math.min(10, event.remaining)}
                    className="flex-1 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    value={formData.tickets}
                    onChange={e => setFormData({ ...formData, tickets: parseInt(e.target.value) })}
                  />
                  <span className="w-12 text-center font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded border border-indigo-100">{formData.tickets}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-indigo-50 p-4 rounded-xl space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Event Ticket (x{formData.tickets})</span>
                  <span className="font-semibold text-slate-900">${event.price * formData.tickets}</span>
                </div>
                <div className="flex justify-between text-sm border-t border-indigo-100 pt-2">
                  <span className="text-slate-600">Processing Fee</span>
                  <span className="font-semibold text-slate-900">$0.00</span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t border-indigo-100 pt-2 text-indigo-900">
                  <span>Total Due</span>
                  <span>${total}</span>
                </div>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl">
                <p className="text-xs text-slate-500 leading-relaxed">
                  By clicking "Confirm Booking", you agree to our Terms of Service. A confirmation email will be sent to <strong>{formData.email}</strong>.
                </p>
              </div>
            </div>
          )}

          <div className="mt-8 flex gap-3">
            {step === 2 && (
              <Button type="button" variant="secondary" className="flex-1" onClick={() => setStep(1)}>
                Back
              </Button>
            )}
            <Button type="submit" variant="primary" className="flex-[2]">
              {step === 1 ? 'Continue to Review' : `Pay $${total} & Confirm`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingModal;
