
import React from 'react';
import { Event } from './types';

export const MOCK_EVENTS: Event[] = [
  {
    id: 'e1',
    title: 'Future Tech Summit 2024',
    description: 'Explore the frontiers of AI, Quantum Computing, and Robotics with industry leaders.',
    date: '2024-11-15',
    location: 'San Francisco, CA',
    price: 299,
    category: 'Conference',
    image: 'https://picsum.photos/seed/tech/800/600',
    capacity: 500,
    remaining: 42
  },
  {
    id: 'e2',
    title: 'Creative Coding Workshop',
    description: 'Learn to create stunning visual art using React, Three.js, and shaders.',
    date: '2024-10-20',
    location: 'Austin, TX',
    price: 150,
    category: 'Workshop',
    image: 'https://picsum.photos/seed/code/800/600',
    capacity: 30,
    remaining: 12
  },
  {
    id: 'e3',
    title: 'Indie Jazz Night',
    description: 'An evening of soulful melodies and improvisation featuring local rising stars.',
    date: '2024-10-12',
    location: 'New York, NY',
    price: 45,
    category: 'Concert',
    image: 'https://picsum.photos/seed/jazz/800/600',
    capacity: 100,
    remaining: 0
  },
  {
    id: 'e4',
    title: 'Startup Founders Mixer',
    description: 'Connect with fellow entrepreneurs, investors, and potential co-founders.',
    date: '2024-12-05',
    location: 'Seattle, WA',
    price: 75,
    category: 'Networking',
    image: 'https://picsum.photos/seed/mixer/800/600',
    capacity: 200,
    remaining: 150
  }
];

export const CATEGORIES = ['All', 'Conference', 'Workshop', 'Concert', 'Networking'];
