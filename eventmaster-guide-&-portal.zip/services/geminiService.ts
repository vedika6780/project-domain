
import { GoogleGenAI } from "@google/genai";
import { MOCK_EVENTS } from "../constants";

// Fix: Strictly follow guidelines to use process.env.API_KEY directly
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_PROMPT = `You are the EventMaster AI Guide. Your job is to help users navigate this event booking portal.
Available events in our database:
${JSON.stringify(MOCK_EVENTS, null, 2)}

Instructions:
1. Help users find events based on their interests (category, location, price).
2. Explain how to book an event: Browse -> Select Event -> Click Book Now -> Fill Form -> Confirm.
3. Answer questions about specific events listed above.
4. If an event is sold out (remaining = 0), suggest similar events.
5. Be professional, friendly, and concise.
6. Use Markdown for formatting.`;

export const getGeminiResponse = async (userPrompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    // Directly access .text property as per guidelines
    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting to my brain right now. Please try again!";
  }
};
