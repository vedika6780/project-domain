
import React, { useState, useMemo } from 'react';
import { MOCK_EVENTS, CATEGORIES } from './constants';
import { AppView, Event, Booking } from './types';
import Header from './components/Header';
import EventCard from './components/EventCard';
import BookingModal from './components/BookingModal';
import ChatAssistant from './components/ChatAssistant';
import Dashboard from './components/Dashboard';
import Button from './components/Button';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('home');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeBookingEvent, setActiveBookingEvent] = useState<Event | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const filteredEvents = useMemo(() => {
    return MOCK_EVENTS.filter(event => {
      const matchesCategory = selectedCategory === 'All' || event.category === selectedCategory;
      const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           event.location.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleBookingComplete = (booking: Booking) => {
    setBookings(prev => [booking, ...prev]);
    setActiveBookingEvent(null);
    setShowSuccessToast(true);
    setTimeout(() => setShowSuccessToast(false), 5000);
  };

  const renderHome = () => (
    <div className="space-y-12">
      <section className="relative h-[400px] rounded-3xl overflow-hidden flex items-center justify-center text-center p-6">
        <div className="absolute inset-0 bg-indigo-900">
          <img src="https://picsum.photos/seed/hero/1600/900" alt="Hero" className="w-full h-full object-cover opacity-30 mix-blend-overlay" />
        </div>
        <div className="relative z-10 max-w-2xl space-y-6">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight">
            The Future of <span className="text-indigo-400">Experiences</span> Starts Here
          </h1>
          <p className="text-indigo-100 text-lg md:text-xl font-medium">
            Explore world-class workshops, summits, and performances. Book your spot in seconds.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" onClick={() => setView('events')}>Browse Events</Button>
            <Button size="lg" variant="secondary" onClick={() => setView('admin-dashboard')}>Organizer Portal</Button>
          </div>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Featured Events</h2>
            <p className="text-slate-500">Curated experiences just for you</p>
          </div>
          <button onClick={() => setView('events')} className="text-indigo-600 font-semibold hover:text-indigo-700 flex items-center gap-1 group">
            View All <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {MOCK_EVENTS.slice(0, 3).map(event => (
            <EventCard key={event.id} event={event} onBook={setActiveBookingEvent} />
          ))}
        </div>
      </section>
    </div>
  );

  const renderEvents = () => (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                selectedCategory === cat 
                  ? 'bg-indigo-600 text-white shadow-md' 
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-64">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input 
            type="text"
            placeholder="Search events..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredEvents.length > 0 ? (
          filteredEvents.map(event => (
            <EventCard key={event.id} event={event} onBook={setActiveBookingEvent} />
          ))
        ) : (
          <div className="col-span-full py-20 text-center space-y-4">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto">
              <svg className="w-10 h-10 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            </div>
            <h3 className="text-xl font-bold text-slate-900">No events found</h3>
            <p className="text-slate-500">Try adjusting your filters or search keywords.</p>
            <Button variant="outline" onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}>Clear all filters</Button>
          </div>
        )}
      </div>
    </div>
  );

  const renderMyBookings = () => (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">My Bookings</h2>
        <span className="text-sm font-medium px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full">{bookings.length} reservations</span>
      </div>

      {bookings.length > 0 ? (
        <div className="space-y-4">
          {bookings.map(booking => {
            const event = MOCK_EVENTS.find(e => e.id === booking.eventId);
            return (
              <div key={booking.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-6 hover:border-indigo-200 transition-colors group">
                <div className="w-full md:w-32 h-32 rounded-xl overflow-hidden shrink-0">
                  <img src={event?.image} alt={event?.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-bold text-slate-900">{event?.title}</h3>
                    <span className="text-xs font-bold px-2 py-1 bg-green-100 text-green-700 rounded-lg uppercase tracking-wider">{booking.status}</span>
                  </div>
                  <p className="text-slate-500 text-sm">{event?.location} • {event?.date}</p>
                  <div className="flex gap-4 pt-4 border-t border-slate-50 mt-4 text-sm font-medium">
                    <div className="text-slate-400">ID: <span className="text-slate-900 font-bold">{booking.id}</span></div>
                    <div className="text-slate-400">Tickets: <span className="text-slate-900 font-bold">{booking.tickets}</span></div>
                    <div className="text-slate-400">Total: <span className="text-indigo-600 font-bold">${booking.totalPrice}</span></div>
                  </div>
                </div>
                <div className="flex md:flex-col justify-end gap-2 shrink-0">
                  <Button variant="outline" size="sm">Download PDF</Button>
                  <Button variant="secondary" size="sm">Add to Calendar</Button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
          <p className="text-slate-400 mb-4 font-medium">You haven't booked any events yet.</p>
          <Button onClick={() => setView('events')}>Discover Events</Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen pb-20">
      <Header currentView={view} setView={setView} />
      
      <main className="max-w-7xl mx-auto px-4 pt-24">
        {view === 'home' && renderHome()}
        {view === 'events' && renderEvents()}
        {view === 'my-bookings' && renderMyBookings()}
        {view === 'admin-dashboard' && <Dashboard bookings={bookings} />}
      </main>

      <ChatAssistant />

      {activeBookingEvent && (
        <BookingModal 
          event={activeBookingEvent} 
          onClose={() => setActiveBookingEvent(null)}
          onComplete={handleBookingComplete}
        />
      )}

      {showSuccessToast && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 animate-in fade-in slide-in-from-top-4">
          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
          </div>
          <div>
            <p className="font-bold">Booking Confirmed!</p>
            <p className="text-slate-400 text-sm">Check your email for tickets.</p>
          </div>
          <button onClick={() => setShowSuccessToast(false)} className="ml-4 text-slate-500 hover:text-white">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
      )}

      <footer className="mt-20 border-t border-slate-200 py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2 space-y-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <div className="w-8 h-8 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold">E</div>
              <span className="text-xl font-bold tracking-tight text-slate-900">EventMaster</span>
            </div>
            <p className="text-slate-500 max-w-sm">Making unforgettable experiences accessible to everyone, everywhere. Join thousands of creators and explorers today.</p>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold text-slate-900">Quick Links</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><button onClick={() => setView('events')} className="hover:text-indigo-600 transition-colors">Browse Events</button></li>
              <li><button onClick={() => setView('admin-dashboard')} className="hover:text-indigo-600 transition-colors">For Organizers</button></li>
              <li><button className="hover:text-indigo-600 transition-colors">Help Center</button></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold text-slate-900">Connect</h4>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-600 hover:border-indigo-200 cursor-pointer transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
              </div>
              {/* Add more icons as needed */}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
