
export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  price: number;
  category: 'Conference' | 'Workshop' | 'Concert' | 'Networking';
  image: string;
  capacity: number;
  remaining: number;
}

export interface Booking {
  id: string;
  eventId: string;
  customerName: string;
  customerEmail: string;
  tickets: number;
  totalPrice: number;
  status: 'confirmed' | 'pending' | 'cancelled';
  timestamp: string;
}

export type AppView = 'home' | 'events' | 'my-bookings' | 'admin-dashboard';

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}
